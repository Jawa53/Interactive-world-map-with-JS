var settings = document.getElementById(settings);
var transparent = document.getElementsByClassName(transparent);
var map = document.getElementById(map);
var profil = document.getElementsByClassName(profil);



